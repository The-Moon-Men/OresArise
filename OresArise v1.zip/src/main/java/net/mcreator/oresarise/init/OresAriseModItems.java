
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.oresarise.init;

import net.minecraft.world.item.Item;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.BlockItem;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.Registry;

import net.mcreator.oresarise.item.SketchiteIngotItem;
import net.mcreator.oresarise.item.CopiniumSwordItem;
import net.mcreator.oresarise.item.CopiniumShovelItem;
import net.mcreator.oresarise.item.CopiniumPickaxeItem;
import net.mcreator.oresarise.item.CopiniumIngotItem;
import net.mcreator.oresarise.item.CopiniumHoeItem;
import net.mcreator.oresarise.item.CopiniumAxeItem;
import net.mcreator.oresarise.item.CopiniumArmorItem;
import net.mcreator.oresarise.item.AndriteSwordItem;
import net.mcreator.oresarise.item.AndriteShovelItem;
import net.mcreator.oresarise.item.AndriteShardsItem;
import net.mcreator.oresarise.item.AndritePickaxeItem;
import net.mcreator.oresarise.item.AndriteItem;
import net.mcreator.oresarise.item.AndriteHoeItem;
import net.mcreator.oresarise.item.AndriteAxeItem;
import net.mcreator.oresarise.item.AndriteArmorItem;
import net.mcreator.oresarise.OresAriseMod;

public class OresAriseModItems {
	public static Item SKETCHITE_BLOCK;
	public static Item SKETCHITE_ORE;
	public static Item SKETCHITE_INGOT;
	public static Item ANDRITE_ORE;
	public static Item ANDRITE_BLOCK;
	public static Item ANDRITE;
	public static Item ANDRITE_AXE;
	public static Item ANDRITE_PICKAXE;
	public static Item ANDRITE_SWORD;
	public static Item ANDRITE_SHOVEL;
	public static Item ANDRITE_HOE;
	public static Item ANDRITE_ARMOR_HELMET;
	public static Item ANDRITE_ARMOR_CHESTPLATE;
	public static Item ANDRITE_ARMOR_LEGGINGS;
	public static Item ANDRITE_ARMOR_BOOTS;
	public static Item ANDRITE_SHARDS;
	public static Item COPINIUM_ARMOR_HELMET;
	public static Item COPINIUM_ARMOR_CHESTPLATE;
	public static Item COPINIUM_ARMOR_LEGGINGS;
	public static Item COPINIUM_ARMOR_BOOTS;
	public static Item COPINIUM_BLOCK;
	public static Item COPINIUM_INGOT;
	public static Item COPINIUM_PICKAXE;
	public static Item COPINIUM_AXE;
	public static Item COPINIUM_SWORD;
	public static Item COPINIUM_SHOVEL;
	public static Item COPINIUM_HOE;

	public static void load() {
		SKETCHITE_BLOCK = Registry.register(Registry.ITEM, new ResourceLocation(OresAriseMod.MODID, "sketchite_block"), new BlockItem(OresAriseModBlocks.SKETCHITE_BLOCK, new Item.Properties().tab(CreativeModeTab.TAB_BUILDING_BLOCKS)));
		SKETCHITE_ORE = Registry.register(Registry.ITEM, new ResourceLocation(OresAriseMod.MODID, "sketchite_ore"), new BlockItem(OresAriseModBlocks.SKETCHITE_ORE, new Item.Properties().tab(CreativeModeTab.TAB_BUILDING_BLOCKS)));
		SKETCHITE_INGOT = Registry.register(Registry.ITEM, new ResourceLocation(OresAriseMod.MODID, "sketchite_ingot"), new SketchiteIngotItem());
		ANDRITE_ORE = Registry.register(Registry.ITEM, new ResourceLocation(OresAriseMod.MODID, "andrite_ore"), new BlockItem(OresAriseModBlocks.ANDRITE_ORE, new Item.Properties().tab(CreativeModeTab.TAB_BUILDING_BLOCKS)));
		ANDRITE_BLOCK = Registry.register(Registry.ITEM, new ResourceLocation(OresAriseMod.MODID, "andrite_block"), new BlockItem(OresAriseModBlocks.ANDRITE_BLOCK, new Item.Properties().tab(CreativeModeTab.TAB_BUILDING_BLOCKS)));
		ANDRITE = Registry.register(Registry.ITEM, new ResourceLocation(OresAriseMod.MODID, "andrite"), new AndriteItem());
		ANDRITE_AXE = Registry.register(Registry.ITEM, new ResourceLocation(OresAriseMod.MODID, "andrite_axe"), new AndriteAxeItem());
		ANDRITE_PICKAXE = Registry.register(Registry.ITEM, new ResourceLocation(OresAriseMod.MODID, "andrite_pickaxe"), new AndritePickaxeItem());
		ANDRITE_SWORD = Registry.register(Registry.ITEM, new ResourceLocation(OresAriseMod.MODID, "andrite_sword"), new AndriteSwordItem());
		ANDRITE_SHOVEL = Registry.register(Registry.ITEM, new ResourceLocation(OresAriseMod.MODID, "andrite_shovel"), new AndriteShovelItem());
		ANDRITE_HOE = Registry.register(Registry.ITEM, new ResourceLocation(OresAriseMod.MODID, "andrite_hoe"), new AndriteHoeItem());
		ANDRITE_ARMOR_HELMET = Registry.register(Registry.ITEM, new ResourceLocation(OresAriseMod.MODID, "andrite_armor_helmet"), new AndriteArmorItem.Helmet());
		ANDRITE_ARMOR_CHESTPLATE = Registry.register(Registry.ITEM, new ResourceLocation(OresAriseMod.MODID, "andrite_armor_chestplate"), new AndriteArmorItem.Chestplate());
		ANDRITE_ARMOR_LEGGINGS = Registry.register(Registry.ITEM, new ResourceLocation(OresAriseMod.MODID, "andrite_armor_leggings"), new AndriteArmorItem.Leggings());
		ANDRITE_ARMOR_BOOTS = Registry.register(Registry.ITEM, new ResourceLocation(OresAriseMod.MODID, "andrite_armor_boots"), new AndriteArmorItem.Boots());
		ANDRITE_SHARDS = Registry.register(Registry.ITEM, new ResourceLocation(OresAriseMod.MODID, "andrite_shards"), new AndriteShardsItem());
		COPINIUM_ARMOR_HELMET = Registry.register(Registry.ITEM, new ResourceLocation(OresAriseMod.MODID, "copinium_armor_helmet"), new CopiniumArmorItem.Helmet());
		COPINIUM_ARMOR_CHESTPLATE = Registry.register(Registry.ITEM, new ResourceLocation(OresAriseMod.MODID, "copinium_armor_chestplate"), new CopiniumArmorItem.Chestplate());
		COPINIUM_ARMOR_LEGGINGS = Registry.register(Registry.ITEM, new ResourceLocation(OresAriseMod.MODID, "copinium_armor_leggings"), new CopiniumArmorItem.Leggings());
		COPINIUM_ARMOR_BOOTS = Registry.register(Registry.ITEM, new ResourceLocation(OresAriseMod.MODID, "copinium_armor_boots"), new CopiniumArmorItem.Boots());
		COPINIUM_BLOCK = Registry.register(Registry.ITEM, new ResourceLocation(OresAriseMod.MODID, "copinium_block"), new BlockItem(OresAriseModBlocks.COPINIUM_BLOCK, new Item.Properties().tab(CreativeModeTab.TAB_BUILDING_BLOCKS)));
		COPINIUM_INGOT = Registry.register(Registry.ITEM, new ResourceLocation(OresAriseMod.MODID, "copinium_ingot"), new CopiniumIngotItem());
		COPINIUM_PICKAXE = Registry.register(Registry.ITEM, new ResourceLocation(OresAriseMod.MODID, "copinium_pickaxe"), new CopiniumPickaxeItem());
		COPINIUM_AXE = Registry.register(Registry.ITEM, new ResourceLocation(OresAriseMod.MODID, "copinium_axe"), new CopiniumAxeItem());
		COPINIUM_SWORD = Registry.register(Registry.ITEM, new ResourceLocation(OresAriseMod.MODID, "copinium_sword"), new CopiniumSwordItem());
		COPINIUM_SHOVEL = Registry.register(Registry.ITEM, new ResourceLocation(OresAriseMod.MODID, "copinium_shovel"), new CopiniumShovelItem());
		COPINIUM_HOE = Registry.register(Registry.ITEM, new ResourceLocation(OresAriseMod.MODID, "copinium_hoe"), new CopiniumHoeItem());
	}
}
