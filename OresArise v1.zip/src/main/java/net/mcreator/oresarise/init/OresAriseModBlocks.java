
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.oresarise.init;

import net.minecraft.world.level.block.Block;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.Registry;

import net.mcreator.oresarise.block.SketchiteOreBlock;
import net.mcreator.oresarise.block.SketchiteBlockBlock;
import net.mcreator.oresarise.block.CopiniumBlockBlock;
import net.mcreator.oresarise.block.AndriteOreBlock;
import net.mcreator.oresarise.block.AndriteBlockBlock;
import net.mcreator.oresarise.OresAriseMod;

public class OresAriseModBlocks {
	public static Block SKETCHITE_BLOCK;
	public static Block SKETCHITE_ORE;
	public static Block ANDRITE_ORE;
	public static Block ANDRITE_BLOCK;
	public static Block COPINIUM_BLOCK;

	public static void load() {
		SKETCHITE_BLOCK = Registry.register(Registry.BLOCK, new ResourceLocation(OresAriseMod.MODID, "sketchite_block"), new SketchiteBlockBlock());
		SKETCHITE_ORE = Registry.register(Registry.BLOCK, new ResourceLocation(OresAriseMod.MODID, "sketchite_ore"), new SketchiteOreBlock());
		ANDRITE_ORE = Registry.register(Registry.BLOCK, new ResourceLocation(OresAriseMod.MODID, "andrite_ore"), new AndriteOreBlock());
		ANDRITE_BLOCK = Registry.register(Registry.BLOCK, new ResourceLocation(OresAriseMod.MODID, "andrite_block"), new AndriteBlockBlock());
		COPINIUM_BLOCK = Registry.register(Registry.BLOCK, new ResourceLocation(OresAriseMod.MODID, "copinium_block"), new CopiniumBlockBlock());
	}

	public static void clientLoad() {
		SketchiteBlockBlock.clientInit();
		SketchiteOreBlock.clientInit();
		AndriteOreBlock.clientInit();
		AndriteBlockBlock.clientInit();
		CopiniumBlockBlock.clientInit();
	}
}
