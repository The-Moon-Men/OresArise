
package net.mcreator.oresarise.item;

import net.minecraft.world.item.UseAnim;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Item;
import net.minecraft.world.food.FoodProperties;

import net.mcreator.oresarise.init.OresAriseModTabs;

public class CrushedSketchiteItemItem extends Item {
	public CrushedSketchiteItemItem() {
		super(new Item.Properties().tab(OresAriseModTabs.TAB_ORES_ARISE).stacksTo(64).rarity(Rarity.COMMON).food((new FoodProperties.Builder()).nutrition(-4).saturationMod(0f)

				.build()));
	}

	@Override
	public UseAnim getUseAnimation(ItemStack itemstack) {
		return UseAnim.NONE;
	}

	@Override
	public int getUseDuration(ItemStack itemstack) {
		return 0;
	}
}
