
package net.mcreator.oresarise.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Item;

import net.mcreator.oresarise.init.OresAriseModTabs;

public class CopiniumIngotItem extends Item {
	public CopiniumIngotItem() {
		super(new Item.Properties().tab(OresAriseModTabs.TAB_ORES_ARISE).stacksTo(64).rarity(Rarity.RARE));
	}

	@Override
	public int getUseDuration(ItemStack itemstack) {
		return 0;
	}
}
