
package net.mcreator.oresarise.item;

import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.item.Tier;
import net.minecraft.world.item.PickaxeItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Item;

import net.mcreator.oresarise.init.OresAriseModTabs;
import net.mcreator.oresarise.init.OresAriseModItems;

public class SketchitePickaxeItem extends PickaxeItem {
	public SketchitePickaxeItem() {
		super(new Tier() {
			public int getUses() {
				return 250;
			}

			public float getSpeed() {
				return 6f;
			}

			public float getAttackDamageBonus() {
				return 0f;
			}

			public int getLevel() {
				return 2;
			}

			public int getEnchantmentValue() {
				return 20;
			}

			public Ingredient getRepairIngredient() {
				return Ingredient.of(new ItemStack(OresAriseModItems.SKETCHITE_INGOT));
			}
		}, 1, -3f, new Item.Properties().tab(OresAriseModTabs.TAB_ORES_ARISE));
	}
}
