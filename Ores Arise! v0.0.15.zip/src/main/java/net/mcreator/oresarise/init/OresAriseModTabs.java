
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.oresarise.init;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.resources.ResourceLocation;

import net.fabricmc.fabric.api.client.itemgroup.FabricItemGroupBuilder;

public class OresAriseModTabs {
	public static CreativeModeTab TAB_ORES_ARISE;

	public static void load() {
		TAB_ORES_ARISE = FabricItemGroupBuilder.create(new ResourceLocation("ores_arise", "ores_arise")).icon(() -> new ItemStack(OresAriseModItems.COPINIUM_INGOT)).build();
	}
}
