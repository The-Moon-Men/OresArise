
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.oresarise.init;

import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.Registry;

import net.mcreator.oresarise.item.SketchiteSwordItem;
import net.mcreator.oresarise.item.SketchiteShovelItem;
import net.mcreator.oresarise.item.SketchitePillItem;
import net.mcreator.oresarise.item.SketchitePickaxeItem;
import net.mcreator.oresarise.item.SketchiteIngotItem;
import net.mcreator.oresarise.item.SketchiteHoeItem;
import net.mcreator.oresarise.item.SketchiteAxeItem;
import net.mcreator.oresarise.item.SketchiteArmorItem;
import net.mcreator.oresarise.item.CrushedSketchiteItemItem;
import net.mcreator.oresarise.item.CopiniumSwordItem;
import net.mcreator.oresarise.item.CopiniumShovelItem;
import net.mcreator.oresarise.item.CopiniumPickaxeItem;
import net.mcreator.oresarise.item.CopiniumIngotItem;
import net.mcreator.oresarise.item.CopiniumHoeItem;
import net.mcreator.oresarise.item.CopiniumAxeItem;
import net.mcreator.oresarise.item.CopiniumArmorItem;
import net.mcreator.oresarise.item.AndriteSwordItem;
import net.mcreator.oresarise.item.AndriteShovelItem;
import net.mcreator.oresarise.item.AndriteShardsItem;
import net.mcreator.oresarise.item.AndritePickaxeItem;
import net.mcreator.oresarise.item.AndriteItem;
import net.mcreator.oresarise.item.AndriteHoeItem;
import net.mcreator.oresarise.item.AndriteAxeItem;
import net.mcreator.oresarise.item.AndriteArmorItem;
import net.mcreator.oresarise.OresAriseMod;

public class OresAriseModItems {
	public static Item SKETCHITE_BLOCK;
	public static Item SKETCHITE_ORE;
	public static Item ANDRITE_ORE;
	public static Item ANDRITE_BLOCK;
	public static Item ANDRITE;
	public static Item SKETCHITE_INGOT;
	public static Item ANDRITE_AXE;
	public static Item ANDRITE_PICKAXE;
	public static Item ANDRITE_SWORD;
	public static Item ANDRITE_SHOVEL;
	public static Item ANDRITE_HOE;
	public static Item ANDRITE_ARMOR_HELMET;
	public static Item ANDRITE_ARMOR_CHESTPLATE;
	public static Item ANDRITE_ARMOR_LEGGINGS;
	public static Item ANDRITE_ARMOR_BOOTS;
	public static Item ANDRITE_SHARDS;
	public static Item COPINIUM_ARMOR_HELMET;
	public static Item COPINIUM_ARMOR_CHESTPLATE;
	public static Item COPINIUM_ARMOR_LEGGINGS;
	public static Item COPINIUM_ARMOR_BOOTS;
	public static Item COPINIUM_BLOCK;
	public static Item COPINIUM_INGOT;
	public static Item COPINIUM_PICKAXE;
	public static Item COPINIUM_AXE;
	public static Item COPINIUM_SWORD;
	public static Item COPINIUM_SHOVEL;
	public static Item COPINIUM_HOE;
	public static Item SKETCHITE_PICKAXE;
	public static Item SKETCHITE_AXE;
	public static Item SKETCHITE_SWORD;
	public static Item SKETCHITE_SHOVEL;
	public static Item SKETCHITE_HOE;
	public static Item SKETCHITE_PILL;
	public static Item SKETCHITE_ARMOR_HELMET;
	public static Item SKETCHITE_ARMOR_CHESTPLATE;
	public static Item SKETCHITE_ARMOR_LEGGINGS;
	public static Item SKETCHITE_ARMOR_BOOTS;
	public static Item CRUSHED_SKETCHITE_ITEM;

	public static void load() {
		SKETCHITE_BLOCK = Registry.register(Registry.ITEM, new ResourceLocation(OresAriseMod.MODID, "sketchite_block"), new BlockItem(OresAriseModBlocks.SKETCHITE_BLOCK, new Item.Properties().tab(OresAriseModTabs.TAB_ORES_ARISE)));
		SKETCHITE_ORE = Registry.register(Registry.ITEM, new ResourceLocation(OresAriseMod.MODID, "sketchite_ore"), new BlockItem(OresAriseModBlocks.SKETCHITE_ORE, new Item.Properties().tab(OresAriseModTabs.TAB_ORES_ARISE)));
		ANDRITE_ORE = Registry.register(Registry.ITEM, new ResourceLocation(OresAriseMod.MODID, "andrite_ore"), new BlockItem(OresAriseModBlocks.ANDRITE_ORE, new Item.Properties().tab(OresAriseModTabs.TAB_ORES_ARISE)));
		ANDRITE_BLOCK = Registry.register(Registry.ITEM, new ResourceLocation(OresAriseMod.MODID, "andrite_block"), new BlockItem(OresAriseModBlocks.ANDRITE_BLOCK, new Item.Properties().tab(OresAriseModTabs.TAB_ORES_ARISE)));
		ANDRITE = Registry.register(Registry.ITEM, new ResourceLocation(OresAriseMod.MODID, "andrite"), new AndriteItem());
		SKETCHITE_INGOT = Registry.register(Registry.ITEM, new ResourceLocation(OresAriseMod.MODID, "sketchite_ingot"), new SketchiteIngotItem());
		ANDRITE_AXE = Registry.register(Registry.ITEM, new ResourceLocation(OresAriseMod.MODID, "andrite_axe"), new AndriteAxeItem());
		ANDRITE_PICKAXE = Registry.register(Registry.ITEM, new ResourceLocation(OresAriseMod.MODID, "andrite_pickaxe"), new AndritePickaxeItem());
		ANDRITE_SWORD = Registry.register(Registry.ITEM, new ResourceLocation(OresAriseMod.MODID, "andrite_sword"), new AndriteSwordItem());
		ANDRITE_SHOVEL = Registry.register(Registry.ITEM, new ResourceLocation(OresAriseMod.MODID, "andrite_shovel"), new AndriteShovelItem());
		ANDRITE_HOE = Registry.register(Registry.ITEM, new ResourceLocation(OresAriseMod.MODID, "andrite_hoe"), new AndriteHoeItem());
		ANDRITE_ARMOR_HELMET = Registry.register(Registry.ITEM, new ResourceLocation(OresAriseMod.MODID, "andrite_armor_helmet"), new AndriteArmorItem.Helmet());
		ANDRITE_ARMOR_CHESTPLATE = Registry.register(Registry.ITEM, new ResourceLocation(OresAriseMod.MODID, "andrite_armor_chestplate"), new AndriteArmorItem.Chestplate());
		ANDRITE_ARMOR_LEGGINGS = Registry.register(Registry.ITEM, new ResourceLocation(OresAriseMod.MODID, "andrite_armor_leggings"), new AndriteArmorItem.Leggings());
		ANDRITE_ARMOR_BOOTS = Registry.register(Registry.ITEM, new ResourceLocation(OresAriseMod.MODID, "andrite_armor_boots"), new AndriteArmorItem.Boots());
		ANDRITE_SHARDS = Registry.register(Registry.ITEM, new ResourceLocation(OresAriseMod.MODID, "andrite_shards"), new AndriteShardsItem());
		COPINIUM_ARMOR_HELMET = Registry.register(Registry.ITEM, new ResourceLocation(OresAriseMod.MODID, "copinium_armor_helmet"), new CopiniumArmorItem.Helmet());
		COPINIUM_ARMOR_CHESTPLATE = Registry.register(Registry.ITEM, new ResourceLocation(OresAriseMod.MODID, "copinium_armor_chestplate"), new CopiniumArmorItem.Chestplate());
		COPINIUM_ARMOR_LEGGINGS = Registry.register(Registry.ITEM, new ResourceLocation(OresAriseMod.MODID, "copinium_armor_leggings"), new CopiniumArmorItem.Leggings());
		COPINIUM_ARMOR_BOOTS = Registry.register(Registry.ITEM, new ResourceLocation(OresAriseMod.MODID, "copinium_armor_boots"), new CopiniumArmorItem.Boots());
		COPINIUM_BLOCK = Registry.register(Registry.ITEM, new ResourceLocation(OresAriseMod.MODID, "copinium_block"), new BlockItem(OresAriseModBlocks.COPINIUM_BLOCK, new Item.Properties().tab(OresAriseModTabs.TAB_ORES_ARISE)));
		COPINIUM_INGOT = Registry.register(Registry.ITEM, new ResourceLocation(OresAriseMod.MODID, "copinium_ingot"), new CopiniumIngotItem());
		COPINIUM_PICKAXE = Registry.register(Registry.ITEM, new ResourceLocation(OresAriseMod.MODID, "copinium_pickaxe"), new CopiniumPickaxeItem());
		COPINIUM_AXE = Registry.register(Registry.ITEM, new ResourceLocation(OresAriseMod.MODID, "copinium_axe"), new CopiniumAxeItem());
		COPINIUM_SWORD = Registry.register(Registry.ITEM, new ResourceLocation(OresAriseMod.MODID, "copinium_sword"), new CopiniumSwordItem());
		COPINIUM_SHOVEL = Registry.register(Registry.ITEM, new ResourceLocation(OresAriseMod.MODID, "copinium_shovel"), new CopiniumShovelItem());
		COPINIUM_HOE = Registry.register(Registry.ITEM, new ResourceLocation(OresAriseMod.MODID, "copinium_hoe"), new CopiniumHoeItem());
		SKETCHITE_PICKAXE = Registry.register(Registry.ITEM, new ResourceLocation(OresAriseMod.MODID, "sketchite_pickaxe"), new SketchitePickaxeItem());
		SKETCHITE_AXE = Registry.register(Registry.ITEM, new ResourceLocation(OresAriseMod.MODID, "sketchite_axe"), new SketchiteAxeItem());
		SKETCHITE_SWORD = Registry.register(Registry.ITEM, new ResourceLocation(OresAriseMod.MODID, "sketchite_sword"), new SketchiteSwordItem());
		SKETCHITE_SHOVEL = Registry.register(Registry.ITEM, new ResourceLocation(OresAriseMod.MODID, "sketchite_shovel"), new SketchiteShovelItem());
		SKETCHITE_HOE = Registry.register(Registry.ITEM, new ResourceLocation(OresAriseMod.MODID, "sketchite_hoe"), new SketchiteHoeItem());
		SKETCHITE_PILL = Registry.register(Registry.ITEM, new ResourceLocation(OresAriseMod.MODID, "sketchite_pill"), new SketchitePillItem());
		SKETCHITE_ARMOR_HELMET = Registry.register(Registry.ITEM, new ResourceLocation(OresAriseMod.MODID, "sketchite_armor_helmet"), new SketchiteArmorItem.Helmet());
		SKETCHITE_ARMOR_CHESTPLATE = Registry.register(Registry.ITEM, new ResourceLocation(OresAriseMod.MODID, "sketchite_armor_chestplate"), new SketchiteArmorItem.Chestplate());
		SKETCHITE_ARMOR_LEGGINGS = Registry.register(Registry.ITEM, new ResourceLocation(OresAriseMod.MODID, "sketchite_armor_leggings"), new SketchiteArmorItem.Leggings());
		SKETCHITE_ARMOR_BOOTS = Registry.register(Registry.ITEM, new ResourceLocation(OresAriseMod.MODID, "sketchite_armor_boots"), new SketchiteArmorItem.Boots());
		CRUSHED_SKETCHITE_ITEM = Registry.register(Registry.ITEM, new ResourceLocation(OresAriseMod.MODID, "crushed_sketchite_item"), new CrushedSketchiteItemItem());
	}
}
