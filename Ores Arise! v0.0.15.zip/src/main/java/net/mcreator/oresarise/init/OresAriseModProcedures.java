
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.oresarise.init;

import net.mcreator.oresarise.procedures.SketchitePillRightclickedProcedure;
import net.mcreator.oresarise.procedures.SketchiteArmorLeggingsTickEventProcedure;
import net.mcreator.oresarise.procedures.SketchiteArmorHelmetTickEventProcedure;
import net.mcreator.oresarise.procedures.SketchiteArmorBootsTickEventProcedure;
import net.mcreator.oresarise.procedures.SketchiteArmorBodyTickEventProcedure;
import net.mcreator.oresarise.procedures.CopiniumFullSetBonusProcedure;

@SuppressWarnings("InstantiationOfUtilityClass")
public class OresAriseModProcedures {
	public static void load() {
		new SketchitePillRightclickedProcedure();
		new SketchiteArmorHelmetTickEventProcedure();
		new SketchiteArmorBodyTickEventProcedure();
		new SketchiteArmorLeggingsTickEventProcedure();
		new SketchiteArmorBootsTickEventProcedure();
		new CopiniumFullSetBonusProcedure();
	}
}
