
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.oresarise.init;

import net.mcreator.oresarise.procedures.SketchitePillRightclickedProcedure;

@SuppressWarnings("InstantiationOfUtilityClass")
public class OresAriseModProcedures {
	public static void load() {
		new SketchitePillRightclickedProcedure();
	}
}
